import pygame
import os
import random
from settings import *


class Items(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((10, 10))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.rect.centerx = random.randrange(0, WIDTH)
        self.rect.bottom = random.randrange(-5000, -1000)
        self.speedy = 5         # 道具下降速度

    def update(self):
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT:        # 如果道具超出螢幕，重製位置
            self.rect.bottom = random.randrange(-5000, -1000)
            self.rect.bottom = 0
            self.rect.y += self.speedy





