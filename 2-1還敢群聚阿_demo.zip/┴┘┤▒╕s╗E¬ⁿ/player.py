import pygame
from settings import *
import os


# 匯入圖片


class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((50, 40))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect = self.image.get_rect()
        self.radius = 20
        # pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 8
        self.health = 5
        self.lives = 3
        self.hidden = False
        self.gun = 1
        self.gun_time = 0

    def update(self):
        key_pressed = pygame.key.get_pressed()
        if key_pressed[pygame.K_RIGHT]:
            self.rect.x += self.speedx
        if key_pressed[pygame.K_LEFT]:
            self.rect.x -= self.speedx

        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0

    def shoot(self, all_sprite, bullets):    # all_sprite為Argument, 這邊從主程式傳進來後，可開始射擊
        # if not (self.hidden):
        if self.gun == 1:
            bullet = Bullet(self.rect.centerx, self.rect.top)           # 一開始只有一顆子彈，發射位置
            all_sprite.add(bullet)                                      # add回去那個all_sprites才能顯示出來
            bullets.add(bullet)
        elif self.gun >= 2:                                             # 吃到道具會讓射擊子彈變兩顆self.gun會變成2
            bullet1 = Bullet(self.rect.left, self.rect.centery)         # 2顆子彈發射的位置A
            bullet2 = Bullet(self.rect.right, self.rect.centery)        # 2顆子彈發射的位置B
            all_sprite.add(bullet1)
            all_sprite.add(bullet2)
            bullets.add(bullet1)
            bullets.add(bullet2)

    # def hide(self):
    #     self.hidden = True
    #     self.hide_time = pygame.time.get_ticks()

    def gunup(self):
        self.gun += 1
        self.gun_time = pygame.time.get_ticks()


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((10, 20))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speedy = -10         # 速度10往上飛

    def update(self):
        self.rect.y += self.speedy
        if self.rect.bottom < 0:
            self.kill()

