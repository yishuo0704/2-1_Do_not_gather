import pygame
import os

# screen size
WIDTH = 500
HEIGHT = 600
# frame rate
FPS = 60
# color
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)

# image
# BACKGROUND_IMAGE = pygame.image.load(os.path.join("images", "Map.png"))