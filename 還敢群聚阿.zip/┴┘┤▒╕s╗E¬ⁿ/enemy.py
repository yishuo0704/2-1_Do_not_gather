import pygame
import random
from player import *
import os

FPS = 60
WIDTH = 500
HEIGHT = 600

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)


class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((30, 30))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.radius = int(self.rect.width * 0.85 / 2)
        # pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
        self.rect.x = random.randrange(0, WIDTH - self.rect.width)  # 掉下隨機水平位置
        self.rect.y = random.randrange(-100, -40)  # 掉下隨機垂直位置
        self.speedx = random.randrange(-3, 3)  # 掉下隨機水平速度(負值是讓他不會只往右邊)
        self.speedy = random.randrange(2, 3)  # 掉下隨機垂直速度
        self.total_degree = 0
        self.rot_degree = random.randrange(-3, 3)

    def update(self):
        self.rotate()
        self.rect.y += self.speedy  # 更新(y座標更新垂直速度位置)
        self.rect.x += self.speedx  # 更新(x座標更新垂直速度位置)
        if self.rect.top > HEIGHT or self.rect.left > WIDTH or self.rect.right < 0:  # 如果超過高度、寬度則重製掉下(不超出邊界)
            self.rect.x = random.randrange(0, WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(2, 10)
            self.speedx = random.randrange(-3, 3)

    def rotate(self):
        self.total_degree += self.rot_degree
        self.total_degree = self.total_degree % 360
        # self.image = pygame.transform.rotate(self.image_ori, self.total_degree)
        center = self.rect.center
        self.rect = self.image.get_rect()
        self.rect.center = center

