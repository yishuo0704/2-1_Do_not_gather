import pygame
import os
import random

WIDTH = 500
HEIGHT = 600

WHITE = (255, 255, 255)

class Items(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((10, 10))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.rect.centerx = random.randrange(0, WIDTH)
        self.rect.bottom = 0
        self.speedy = 5         # 道具下降速度

    def update(self):
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT:        # 如果道具超出螢幕，重製位置
            self.rect.centerx = random.randrange(50, 450)
            self.rect.bottom = 0
            self.rect.y += self.speedy





