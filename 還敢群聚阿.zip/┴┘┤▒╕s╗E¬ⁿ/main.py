import os
import pygame
from enemy import *
from player import *
from items import *

FPS = 60
WIDTH = 500
HEIGHT = 600

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)

# 遊戲初始化 and 創建視窗
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("還敢群聚啊")
clock = pygame.time.Clock()


all_sprites = pygame.sprite.Group()  # 這個sprite.group是pygame內建的東西，下面update跟draw可以把畫面顯示出來
player = Player()                    # 創建一個player的物件
all_sprites.add(player)              # 把player的物件加入sprite.group

enemies = pygame.sprite.Group()      # 創建enemy的group，把所有新增的敵人存入
bullets = pygame.sprite.Group()      # 創建bullet的group，把所有新增的子彈存起來，要有shoot的動作才會新增子彈

items = pygame.sprite.Group()        # 創建items的group，把所有新增的道具存入
item = Items()
all_sprites.add(item)
items.add(item)                      # 將 item 存入items的group，作為之後碰撞用



for i in range(5):
    e = Enemy()
    all_sprites.add(e)
    enemies.add(e)


# 遊戲迴圈
running = True
while running:
    clock.tick(FPS)
    # 取得輸入
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.shoot(all_sprites, bullets)  # all_sprites會記錄下每個物件，sprites為處理顯示的物件
                                                    # bullets這個group的物件傳進shoot，才能做新增子彈到bullets，下面兩個ememies
                                                    # 下面兩個ememies，跟bullets兩個group才能去做碰撞判定
    # 更新遊戲
    all_sprites.update()
    # 判斷敵人 子彈相撞
    hits = pygame.sprite.groupcollide(enemies, bullets, True, True)
    for h in hits:
        e = Enemy()
        all_sprites.add(e)
        enemies.add(e)
    # 判斷石頭 玩家相撞
    hits = pygame.sprite.spritecollide(player, enemies, True)
    if hits:
        running = False
    # 判斷道具 玩家相撞
    hits = pygame.sprite.spritecollide(player, items, True)
    for h in hits:
        player.gunup()

    # 畫面顯示
    screen.fill(BLACK)
    all_sprites.draw(screen)
    pygame.display.update()

pygame.quit()